    export const Todoform = ({ text, addTask, taskValueChange }) => {
    return (
        <div className="todo-form">
            <h1>Todo List</h1>
            <input type="text" value={text} onChange={(e) => taskValueChange(e.target.value)} />
            <button onClick={() => addTask()}>Add</button>
        </div>
    );
};

