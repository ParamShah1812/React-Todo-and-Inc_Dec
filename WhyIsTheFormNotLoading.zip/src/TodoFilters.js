export const TodoFilters = ({showAll, showPending, showDone}) => {
    return(
    <> 
    <a href= "#"onClick={showAll}>Show All</a>
    <br />
    <br />
    <a onClick={showPending}>Show Pending</a>
    <br />
    <a onClick={showDone}>Show Done</a>
    <br />
    </>
)};